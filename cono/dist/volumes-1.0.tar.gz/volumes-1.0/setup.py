from setuptools import setup

setup(
    name='volumes',
    version=1.0,
    description='This module calculate volumes',
    author='JZHV',
    author_email='josehdz3321@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['volumes']
)