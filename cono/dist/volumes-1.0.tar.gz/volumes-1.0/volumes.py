from math import  pi

def cono_area(R:float, g:float)->float:
    return pi*R *(g+R)

def cono_volumen(R:float, h:float)->float:
    return  1/3 * pi*R**2 * h